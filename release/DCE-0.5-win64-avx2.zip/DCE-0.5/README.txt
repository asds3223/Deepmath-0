DCE 0.5 - 15x15 프리스타일 오목 엔진 (Windows x64, AVX2 전용)
==============================================================

- 순수 고전평가 C (Yixin 식 패턴 점수표 + 3x3 국소 모양 표, Rapfi 25 NNUE 증류 점수 내장) + 자체 선택 탐색
- 싱글코어, 폰더링 없음 (상대 차례에는 아무 계산도 하지 않음)
- 파일 하나로 동작 (가중치 내장, 추가 DLL 없음)
- CPU 요구: AVX2 지원 (Intel Haswell 2013 이후 / AMD Ryzen 이후)

사용법
------
1) Piskvork / Yixin Board 등 Gomocup 프로토콜 GUI 에서 pbrain-dce.exe 를 엔진으로 등록
   (규칙: 프리스타일(rule 0), 판 크기 15)
2) 속도 측정: 명령 프롬프트에서  pbrain-dce.exe bench

옵션 (GUI 의 엔진 명령줄 또는 직접 실행 시)
  --tt-mb N          전치표 크기 MB (기본 128, GUI 의 max_memory 가 더 작으면 그에 맞춤)
  --vcf 1            연속 4 강제승 판정기 켜기 (기본 끔: 속도 우선)
  --vcf-budget N     VCF 1회당 착수 한도 (기본 200)
  --model 파일.dce   다른 가중치 파일 사용

출력 (GUI 의 메시지 창, 반복 깊이마다 한 줄)
  MESSAGE depth 9 sel 16 ev 351 wr 85.3% nodes 349.3k nps 547.4k tm 638 pv h8 h9 g10 ...
    depth  완료한 반복 깊이 (일반 깊이)
    sel    선택 깊이: 정지 탐색 포함 실제로 도달한 최대 수 깊이
    ev     평가 점수 (+M7 = 7수 안에 이김, -M5 = 5수 안에 짐)
    wr     둘 차례 기준 승률 추정
    nodes  탐색 노드 수,  nps 초당 노드,  tm 경과 ms
    pv     예상 수순 (열 a~o, 행 1~15)
  MESSAGE [move h8] ...   실제로 둔 수와 최종 지표

시간: GUI 의 timeout_turn(수당 시간), time_left(남은 시간)를 따른다.
      수당 시간 = min(수당 한도, 남은 시간/15) 에서 통신 여유를 뺀 값.
